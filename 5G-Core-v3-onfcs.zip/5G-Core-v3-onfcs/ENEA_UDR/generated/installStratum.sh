#!/bin/bash


#docker load -i stratum_ems.3.2.9.tar
#docker load -i stratum_fe.3.2.9.tar
file_stratum=$1
udrNamespace=$2
valuesfile=$3
chartsfile=$4
release=$(cat ${file_stratum} | grep version | head -n1 | awk '{print $2}')




helm install --timeout 900s --version ${release} --values ${valuesfile} region1 ${chartsfile} --debug -n ${udrNamespace} --wait --kubeconfig /tmp/kubeconfig
#helm list -A

#kubectl get pods -n${udrNamespace}

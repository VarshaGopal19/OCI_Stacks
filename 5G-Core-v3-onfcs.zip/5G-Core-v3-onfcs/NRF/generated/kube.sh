#!/bin/bash

db_ns=$1
file_name=$2

kubectl cp $file_name ndbappmysqld-0:/home/mysql -n $db_ns -c mysqlndbcluster --kubeconfig /tmp/kubeconfig
kubectl exec -i ndbappmysqld-0 -n $db_ns --kubeconfig /tmp/kubeconfig -- mysql -h 127.0.0.1 -uroot -pRootrootrootrootroot1% < $file_name 
#!/bin/bash

ns=$1
sed -i "s/db/$ns/g" ../charts/occndbtier/values.yaml
print_help() {
    cat <<EOF
NAME
    mksecrets.sh - helper function to create k8s secrets required for
        mysql-cluster installation without printing the passwords on the
        command line.  It creates kubernetes secrets for root user and
        monitor and/or geo replication services.

SYNOPSIS
    # This bash env variable is required before running $0:

    export OCCNE_NAMESPACE=<namespace>
        # kubernetes namespace

    mksecrets.sh [-h | --help | --replonly]

OPTIONS
    -h | --help
        Print this help message and exit.

    --replonly
        Execute only the geo replication k8s secret. To be used on a
        system previously installed without geo replication.

EXAMPLE
    Create mysql root user and db monitor service. It will let user chose if
    geo replication k8s secret is also created:

        export OCCNE_NAMESPACE=default

        ../mksecrets.sh

    create only geo replication service k8s secret:

        export OCCNE_NAMESPACE=default

        ../mksecrets.sh --replonly

EOF
}



print_env_vars() {
    echo "    OCCNE_NAMESPACE=$ns"
}

dononrepl="yes"

if [[ "$1" == "-h" || "$1" == "--help" ]]; then
    print_help
    exit 0
fi

if [[ "$#" > "1" ]]; then
    echo "Error: invalid parameter(s)."
    echo "For more information, run: $0 --help"
    exit 1
fi


if [[ -z "$ns" ]]; then
    echo "Error: all environment variables below must be set up with appropriate values:"
    echo ""
    print_env_vars
    echo ""
    echo "For more information, run: $0 --help"
    exit 3
fi

echo "Using the following values:"
print_env_vars
echo ""

if [[ "$dononrepl" == "yes" ]]; then
    rootpassword="password"
fi

if [[ "$dononrepl" == "yes" ]]; then
    echo -n "Enter mysql user for monitor service (default: occneuser): "
    read monitorUser
    if [[ -z "$monitorUser" ]]; then
        monitorUser="occneuser"
    fi

   
    monitorpassword="password"

fi


    echo -n "Enter mysql user for geo replication service (default: occnerepluser): "
    read replicationUser
    if [[ -z "$replicationUser" ]]; then
        replicationUser="occnerepluser"
    fi

   
    replicationpassword="password"

if [[ "$dononrepl" == "yes" ]]; then
    echo "creating secret for mysql root user..."
    kubectl -n $ns create secret generic occne-mysqlndb-root-secret \
        --from-literal="mysql_root_password=${rootpassword}" --kubeconfig /tmp/kubeconfig

    echo "creating secret for mysql db monitor service user..."
    kubectl -n $ns create secret generic occne-secret-db-monitor-secret \
        --from-literal="mysql_username_for_metrics=${monitorUser}" \
        --from-literal="mysql_password_for_metrics=${monitorpassword}" --kubeconfig /tmp/kubeconfig
fi

    echo "creating secret for mysql db replication service user..."
    kubectl -n $ns create secret generic occne-replication-secret-db-replication-secret \
        --from-literal="mysql_username_for_replication=${replicationUser}" \
        --from-literal="mysql_password_for_replication=${replicationpassword}" --kubeconfig /tmp/kubeconfig

kubectl apply -f ./cndbtier_namespace.yaml -n $ns --kubeconfig /tmp/kubeconfig
echo "done"

exit 0

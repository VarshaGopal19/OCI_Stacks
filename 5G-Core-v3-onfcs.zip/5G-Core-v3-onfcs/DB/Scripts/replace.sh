#!/bin/bash

ns=$1
sed -i "s/$ns/db/g" ../charts/occndbtier/values.yaml